<?php
	include("conn.php");
?>
<script type="text/javascript" src="./js/jquery-1.8.3.js"></script>
 <script src="js/afric.js"></script>
 <link rel="stylesheet" href="css/africam.css" type="text/css" media= "screen"/>
 