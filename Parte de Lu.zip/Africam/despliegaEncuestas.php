<?php
	include("header.php"); 	
	$query=mysql_query("SELECT id_encuesta,nombre,descripcion FROM encuesta WHERE habilitado='1'",$link);
	?>
    
     <table>
    <tr>
    	<td>
        	<div class="logomas">
        	 <a class="link" href="#" onClick="cargar('nuevaEncuesta.php')"><img  src="images/new.png" title="Nuevo"/>Nueva Encuesta</a>
             </div>
        </td>
    </tr>
    </table>
    <table>
    <?php

	while($row=mysql_fetch_array($query)){
		echo "<tr>";
		echo "<td>".$row["nombre"]." &nbsp;</td><td> ".$row["descripcion"]." &nbsp;</td> ";
		
		echo "<td><div class=\"logomas\"><a class=\"link\" href=\"#\" onClick=\"cargar('encuestas.php?idEncuesta='+".$row["id_encuesta"].")\"><img  src=\"images/ver.png\" title=\"Ver\"/>Visualizar</a></div></td></tr>";
		}
?>
	</table>

	