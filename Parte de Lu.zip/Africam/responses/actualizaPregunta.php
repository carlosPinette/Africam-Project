<?php
include ("../header.php");
$texto=$_GET["texto"];
$tipo=$_GET["tipo"];
$idPregunta=$_GET["idPregunta"];

$query=mysql_query("UPDATE pregunta SET texto='".$texto."', tipo='".$tipo."' WHERE id_pregunta='".$idPregunta."'", $link);

?>