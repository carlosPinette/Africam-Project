<?php
	include ("../conn.php");
	$nombre= $_GET["nombre"];
	$descripcion=$_GET["descripcion"];
	$query= "INSERT into encuesta (id_encuesta,nombre,descripcion,habilitado) VALUES ('0','".$nombre."','".$descripcion."','1')";
	$do_query=mysql_query($query,$link);

	$sql=mysql_query("SELECT id_encuesta FROM encuesta ORDER BY id_encuesta DESC limit 1",$link);
	$sql=mysql_result($sql,0);
	echo $sql;
?>