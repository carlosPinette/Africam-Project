<?php
include ("../header.php");
$texto=$_GET["texto"];
$tipo=$_GET["tipo"];
$idencuesta=$_GET["idEncuesta"];

$query=mysql_query("INSERT into pregunta (id_pregunta,texto,tipo,id_encuesta,habilitado) VALUES ('0','".$texto."','".$tipo."','".$idencuesta."','1')",$link);
?>