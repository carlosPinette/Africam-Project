<?php
	include ("../header.php");
	$idPregunta=$_GET["idPregunta"];
	
	$query=mysql_query("DELETE FROM pregunta WHERE id_pregunta ='".$idPregunta."'",$link);
?>